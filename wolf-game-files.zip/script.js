let state=null,seconds=300,timer=null,showRoles=false;
const roles=["หมาป่า","ยาจก","ดูดวง","บริการ์ด","ชาวบ้าน"];
const icons={"หมาป่า":"🐺","ยาจก":"🪙","ดูดวง":"🔮","บริการ์ด":"🛡️","ชาวบ้าน":"🏡"};
const infos={"หมาป่า":"กำจัดผู้เล่นฝ่ายชาวบ้านในตอนกลางคืน","ยาจก":"บทบาทพิเศษของเกม","ดูดวง":"ตรวจสอบบทบาทของผู้เล่นตามกติกา","บริการ์ด":"ปกป้องผู้เล่นตามกติกา","ชาวบ้าน":"ช่วยกันหาหมาป่าและโหวตผู้ต้องสงสัย"};

function shuffle(a){for(let i=a.length-1;i>0;i--){let j=Math.floor(Math.random()*(i+1));[a[i],a[j]]=[a[j],a[i]]}return a}
function esc(s){return String(s).replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]))}
function makePlayers(n,host){
 let names=[host||"คนควบคุม"];for(let i=1;i<n;i++)names.push("ผู้เล่น "+i);
 let rs=[];let wolves=Math.max(1,Math.floor(n/5));
 for(let i=0;i<wolves;i++)rs.push("หมาป่า");
 rs.push("ยาจก","ดูดวง","บริการ์ด");
 while(rs.length<n)rs.push("ชาวบ้าน");
 rs=shuffle(rs.slice(0,n));
 return names.map((name,i)=>({name,role:rs[i],alive:true}));
}
function createRoom(){
 const n=Math.max(5,Math.min(20,Number(document.getElementById("playerCount").value)||8));
 const host=document.getElementById("hostName").value.trim()||"คนควบคุม";
 state={code:String(Math.floor(1000+Math.random()*9000)),players:makePlayers(n,host),round:1,phase:"กลางคืน",host:true};
 start();
}
function joinRoom(){
 const name=document.getElementById("playerName").value.trim();
 const code=document.getElementById("roomCode").value.trim();
 if(!name||code.length!==4){alert("กรอกชื่อและเลขห้องให้ครบ");return}
 alert("ต้นแบบนี้ยังไม่รองรับการจอยข้ามเครื่อง กรุณาใช้หน้าเดียวกันก่อน");
}
function start(){
 document.getElementById("home").classList.add("hidden");
 document.getElementById("game").classList.remove("hidden");
 document.getElementById("hostPanel").classList.remove("hidden");
 document.getElementById("hostRoom").textContent=state.code;
 seconds=300;showRoles=false;clearInterval(timer);
 timer=setInterval(()=>{if(seconds>0)seconds--;else nextRound();renderTimer()},1000);
 render();renderTimer();
}
function renderTimer(){let m=String(Math.floor(seconds/60)).padStart(2,"0"),s=String(seconds%60).padStart(2,"0");document.getElementById("timer").textContent=m+":"+s}
function render(){
 document.getElementById("phase").textContent=state.phase;
 document.getElementById("round").textContent="รอบที่ "+state.round;
 document.getElementById("playerList").innerHTML=state.players.map(p=>`<div class="person ${p.alive?"":"dead"}"><span>${esc(p.name)}</span><span class="status">${p.alive?"🟢 รอด":"☠️ ตาย"}</span></div>`).join("");
 document.getElementById("hostList").innerHTML=state.players.map((p,i)=>`<div class="person"><div><b>${esc(p.name)}</b><div class="note">${showRoles?icons[p.role]+" "+p.role:"บทบาทถูกซ่อน"}</div></div><button class="smallbtn secondary" onclick="toggleAlive(${i})">${p.alive?"☠️ ตายแล้ว":"↩️ ฟื้น"}</button></div>`).join("");
 document.getElementById("victim").innerHTML=state.players.map((p,i)=>`<option value="${i}" ${p.alive?"":"disabled"}>${esc(p.name)}${p.alive?"":" (ตายแล้ว)"}</option>`).join("");
}
function revealRole(){
 const p=state.players[0];
 document.getElementById("roleCard").classList.remove("hidden");
 document.getElementById("roleIcon").textContent=icons[p.role];
 document.getElementById("roleName").textContent=p.role;
 document.getElementById("roleInfo").textContent=infos[p.role];
 document.getElementById("revealBtn").textContent="เปิดไพ่แล้ว";
}
function toggleRoles(){showRoles=!showRoles;render()}
function toggleAlive(i){state.players[i].alive=!state.players[i].alive;render()}
function killPlayer(){const i=Number(document.getElementById("victim").value);if(state.players[i]){state.players[i].alive=false;document.getElementById("message").textContent=state.players[i].name+" ถูกบันทึกว่าตายแล้ว";render()}}
function nextRound(){state.phase=state.phase==="กลางคืน"?"เช้า":"กลางคืน";if(state.phase==="กลางคืน")state.round++;seconds=300;render();renderTimer()}
function resetGame(){clearInterval(timer);state=null;document.getElementById("home").classList.remove("hidden");document.getElementById("game").classList.add("hidden")}
